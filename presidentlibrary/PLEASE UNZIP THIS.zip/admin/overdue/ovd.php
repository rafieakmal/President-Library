<?php
    require '../conn.php';
    $search = isset($_GET['query']) ? $_GET['query']: "";
    if (isset($_GET['query'])) {
        $search_query = isset($_GET['query']) ?
        ' l.loan_id LIKE "%' . $_GET['query']
        . '%" OR o.student_id LIKE "%' . $_GET['query'] . '%" '
        : "";
        $show_query = "SELECT l.loan_id, l.total_day, l.book_id, o.student_id, l.student_card, l.deadline_date, o.status, o.overdue_tax, o.book_id FROM loan l 
        LEFT JOIN overdue o on l.loan_id = o.loan_id WHERE l.status = 'Request' AND" . $search_query;
        $result = mysqli_query($conn, $show_query);
    } else {
        $show_query = "SELECT l.loan_id, l.total_day, l.book_id, o.student_id, l.student_card, l.deadline_date, o.status, o.overdue_tax, o.book_id FROM loan l 
        LEFT JOIN overdue o on l.loan_id = o.loan_id WHERE l.status = 'Request'";
        $result = mysqli_query($conn, $show_query);
    }
?>

<div class="container">
    <br><h1>Overdue Management</h1>
        <br>
        <form class="search-form"  method="get">
            <div class="input-group"><span class="input-group-text"><i class="fa fa-search"></i></span>
            <input class="form-control" type="text" placeholder="I am looking for.." id="search-catalog-field" value="<?= $search?>">
            <button class="btn btn-info text-light" type="button" onclick="sortCatalog()">Search</button></div>
        </form>
        <div class="table-responsive text-center table table-hover table-bordered results">
            <table class="table table-hover table-bordered">
                <thead class="bill-header cs">
                    <tr>
                        <th id="trs-hd-1" class="col-lg-1">No.</th>
                        <th id="trs-hd-2" class="col-lg-2">Student ID</th>
                        <th id="trs-hd-3" class="col-lg-3">Loan ID</th>
                        <th id="trs-hd-4" class="col-lg-2">Borrow Day</th>
                        <th id="trs-hd-4" class="col-lg-2">Tax</th>
                        <th id="trs-hd-6" class="col-lg-2">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $i = 0;
                    while ($row = mysqli_fetch_assoc($result)) {
                        ++$i;?>
                        <tr>
                            <td><?= $i ?></td>
                            <td><?= htmlspecialchars($row["student_id"]) ?></td>
                            <td><?= htmlspecialchars($row["loan_id"]) ?></td>
                            <td><?= htmlspecialchars($row["total_day"]) ?> days</td>
                            <td><?= htmlspecialchars($row["overdue_tax"]) ?></td>
                            <td><button class="btn btn-success" id="edit-data" data-bs-toggle="modal" data-bs-target="#modal-1" data-sid="<?= htmlspecialchars($row["student_id"]) ?>" 
                            data-bkid="<?= htmlspecialchars($row["book_id"]) ?>" 
                            data-deadline="<?= htmlspecialchars($row["deadline_date"]) ?>" data-day="<?= htmlspecialchars($row["total_day"]) ?>" 
                            data-lid="<?= htmlspecialchars($row["loan_id"]) ?>" data-tax="<?= htmlspecialchars($row["overdue_tax"]) ?>" style="margin-left: 5px;width: 37px;"><i class="far fa-edit" style="font-size: 15px;"></i></button></td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<div class="modal fade" role="dialog" id="modal-1" tabindex="-1" aria-labelledby="ModalUtama" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header" style="background: linear-gradient(134deg, var(--bs-yellow) 0%, var(--bs-pink) 100%), var(--bs-blue);">
                <h4 class="modal-title text-light">Overdue Management</h4><button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="overdue/confirm.php" method="post" enctype="multipart/form-data">
                <div class="modal-body">
                    <div class="form-group">
                        <label class="form-label">Loan ID</label>
                        <input class="form-control" type="text" name="loan_id" id="loan_id" style="margin-top: 0px;margin-bottom: 10px;" required readonly>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Student ID</label>
                        <input class="form-control" type="text" name="stud_id" id="stud_id" style="margin-top: 0px;margin-bottom: 10px;" required readonly>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Book ID</label>
                        <input class="form-control" type="text" name="bk_id" id="bk_id" style="margin-top: 0px;margin-bottom: 10px;" required readonly>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Deadline Date</label>
                        <input class="form-control" type="text" name="date_id" id="date_id" style="margin-top: 0px;margin-bottom: 10px;" required readonly>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Days</label>
                        <input class="form-control" type="text" name="total_day" id="total_day" style="margin-top: 0px;margin-bottom: 10px;" required readonly>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Tax</label>
                        <input class="form-control" type="text" name="tax_id" id="tax_id" style="margin-top: 0px;margin-bottom: 10px;" required readonly>
                    </div>
                </div>
                <div class="modal-footer">
                    <button class="btn btn-light" type="button" data-bs-dismiss="modal">Close</button>
                    <button class="btn btn-success link-light" name="submit_modal" type="submit">Confirm</button>
                </div>
            </form>
        </div>
    </div>
</div>
<script>
    $(document).on('click', '#edit-data', function(){
        let stid = $(this).data("sid");
        let lid = $(this).data("lid");
        let bkid = $(this).data("bkid");
        let tax = $(this).data("tax");
        let dead = $(this).data("deadline");
        let day = $(this).data("day");

        $(".modal-body #stud_id").val(stid);
        $(".modal-body #loan_id").val(lid);
        $(".modal-body #tax_id").val(tax);
        $(".modal-body #bk_id").val(bkid);
        $(".modal-body #date_id").val(dead);
        $(".modal-body #total_day").val(day);
    });
</script>
<script>
    const search_field = document.getElementById('search-catalog-field');
    function sortCatalog(){
        const search_value = search_field.value;
        console.log(search_value);
        window.location = 'index.php?page=overdue&query='+search_value;
    }
</script>