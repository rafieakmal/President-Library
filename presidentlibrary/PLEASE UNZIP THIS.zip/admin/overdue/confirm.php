<?php
    session_start();
    require_once 'conn.php';
    if(!isset($_SESSION['admin'])) {
        exit;
    }
    if (isset($_POST['submit_modal'])) {
        $id = trim(htmlspecialchars($_POST['loan_id']));
        $bkid = trim(htmlspecialchars($_POST['bk_id']));
        $studid = trim(htmlspecialchars($_POST['stud_id']));
        $date_line = trim(htmlspecialchars($_POST['date_id']));
        $status = "Returned";
        $show_query = "SELECT * FROM loan WHERE loan_id = '$id' AND status = 'Request'";
        $result = mysqli_query($conn, $show_query);
        if($result) {
            $checkout_query = "UPDATE `loan` SET `status`='$status' WHERE `loan_id`='$id' AND `status` = 'Request'";
            $result_query = mysqli_query($conn, $checkout_query);
            if ($result_query) {
                $delete_query = "DELETE FROM overdue WHERE loan_id = '$id'";
                $delete_result = mysqli_query($conn, $delete_query);
                if($delete_result) {
                    $delete_query2 = "DELETE FROM loan WHERE loan_id = '$id'";
                    $delete_result2 = mysqli_query($conn, $delete_query2);
                    if($delete_result2) {
                        echo "<script>
                            alert('Data Updated!');
                            window.location='../index.php?page=overdue';
                        </script>";
                    } else {
                        echo "<script>
                            alert('Failed to update data!');
                            window.location='../index.php?page=overdue';
                        </script>";
                    }
                } else {
                    echo "<script>
                        alert('Failed to update data!');
                        window.location='../index.php?page=overdue';
                    </script>";
                }
            } else {
                echo "<script>
                    alert('Failed to update data!');
                    window.location='../index.php?page=overdue';
                </script>";
            }
        } else {
            $reason = mysqli_error($conn);
            echo "<script>
                alert('$reason');
                window.location='../index.php?page=overdue';
            </script>";
        }
    }
?>