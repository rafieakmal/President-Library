<?php
    require '../conn.php';
    $search = isset($_GET['query']) ? $_GET['query']: "";
    if (isset($_GET['query'])) {
        $search_query = isset($_GET['query']) ?
        ' WHERE book_name LIKE "%' . $_GET['query']
        . '%" OR book_type LIKE "%' . $_GET['query']
        . '%" OR book_id LIKE "%' . $_GET['query']
        . '%" OR book_desc LIKE "%' . $_GET['query'] . '%" '
        : "";
        $show_query = 'SELECT * FROM book' . $search_query;
        $result = mysqli_query($conn, $show_query);
    } else {
        $show_query = 'SELECT * FROM book';
        $result = mysqli_query($conn, $show_query);
    }
?>

<?php
    if (isset($_POST['submit_modal'])) {
        $id = trim(htmlspecialchars($_POST['book_id2']));
        $id_new = trim(htmlspecialchars($_POST['book_id_new']));
        $name = trim(htmlspecialchars($_POST['book_name']));
        $type = trim(htmlspecialchars($_POST['book_type']));
        $stock = trim(htmlspecialchars($_POST['book_stock']));
        $desc = trim(htmlspecialchars($_POST['book_desc']));
        $pict = $_FILES['book_image']['name'];
        $ext = explode(".", $_FILES['book_image']['name']);
        $image = "img-" . round(microtime(true)) . "." . end($ext);
        $sumber = $_FILES['book_image']['tmp_name'];
        if($pict == '') {
            $query_string = "UPDATE `book` SET `book_id`='$id_new', `book_name`='$name',`book_type`='$type',`book_desc`='$desc', `book_total`='$stock' WHERE `book_id`='$id'";
            $result = mysqli_query($conn, $query_string);
            echo "<script>
                alert('Updated!');
                window.location='./index.php?page=item';
            </script>";
        } else {
            $show_query_first = "SELECT * FROM book WHERE book_id = '$id'";
            $result = mysqli_query($conn, $show_query_first);
            $line = mysqli_fetch_assoc($result);
            $old = $line['book_image'];
            if($result) {
                unlink("../assets/img/book/".$old);
                $query_string = "UPDATE `book` SET `book_id`='$id_new', `book_name`='$name',`book_type`='$type',`book_image`='$image',`book_desc`='$desc', `book_total`='$stock' WHERE `book_id`='$id'";
                $result_new = mysqli_query($conn, $query_string);

                $upload = move_uploaded_file($sumber, "../assets/img/book/" . $image);
                echo "<script>
                    alert('Updated!');
                    window.location='./index.php?page=item';
                    </script>";
            }
        }
    }
?>
<!-- Owl Stylesheets -->
<link rel="stylesheet" href="../admin/item/assets/owlcarousel/assets/owl.carousel.min.css">
<link rel="stylesheet" href="../admin/item/assets/owlcarousel/assets/owl.theme.default.min.css">
<link rel="stylesheet" href="../admin/item/assets/css/item.css">

<script src="../admin/item/assets/vendors/jquery.min.js"></script>
<script src="../admin/item/assets/owlcarousel/owl.carousel.js"></script>

<div class="container">
    <h1>Collections</h1>
</div>

<div class="container">
    <form class="search-form"  method="get">
        <div class="input-group"><span class="input-group-text"><i class="fa fa-search"></i></span>
        <input class="form-control" type="text" placeholder="I am looking for.." id="search-catalog-field" value="<?= $search?>">
        <button class="btn btn-info text-light" type="button" onclick="sortCatalog()">Search</button></div>
    </form><br>
    <div class="row">
        <div class="large-12 columns">
          <div class="owl-carousel owl-theme">
          <?php $i = 0;
            while ($row = mysqli_fetch_assoc($result)) { ?>
                <div class="item">
                    <div class="card p-3">
                        <div class="text-center"> <img src="../assets/img/book/<?= htmlspecialchars($row["book_image"]) ?>" width="200"> </div>
                        <div class="product-details">
                            <div class="buttons d-flex flex-row">
                                <button class="btn btn-warning text-light cart-button btn-block" id="edit-data" data-id="<?= htmlspecialchars($row["book_id"]) ?>"
                                data-name="<?= htmlspecialchars($row["book_name"]) ?>" data-total="<?= htmlspecialchars($row["book_total"]) ?>" 
                                data-image="../assets/img/book/<?= htmlspecialchars($row["book_image"]) ?>" type="button"><span class="dot">1</span>Edit</button>
                                <button class="btn btn-danger text-light cart-button btn-block" style="margin-left: 15px;" type="submit" onclick="confirm('Are You Sure ?')?window.location='product/delete.php?id=<?= $row['book_id'] ?>':null"><span class="dot">1</span>Delete</button>
                            </div>
                            <div class="weight"><p>Available: <?= htmlspecialchars($row["book_total"]) ?></p></div>
                        </div>
                    </div>
                </div>
            <?php } ?>
        </div>
    </div>
</div>

<div class="modal fade" role="dialog" id="modal-utama" tabindex="-1" aria-labelledby="ModalUtama" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header" style="background: linear-gradient(134deg, var(--bs-yellow) 0%, var(--bs-pink) 100%), var(--bs-blue);">
                <h4 class="modal-title text-light">Edit Book</h4><button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form method="post" enctype="multipart/form-data">
                <div class="modal-body">
                    <div class="container" style="width: 227px;">
                        <div class="row">
                            <div class="col-md-12"><img class="img-fluid" id="img_ku" name="img_ku" src="assets/img/OIP%20(3).jpg"></div>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Current Book ID</label>
                        <input class="form-control" type="text" name="book_id2" id="book_id2" style="margin-top: 0px;margin-bottom: 10px;" required readonly>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Book ID</label>
                        <input class="form-control" type="text" name="book_id_new" id="book_id_new" style="margin-top: 0px;margin-bottom: 10px;" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Book Name</label>
                        <input class="form-control" type="text" name="book_name" id="book_name" style="margin-top: 0px;margin-bottom: 10px;" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Book Stock</label>
                        <input class="form-control" type="text" name="book_stock" id="book_stock" style="margin-top: 0px;margin-bottom: 10px;" required>
                    <div class="form-group">
                        <label class="form-label">Book Type</label>
                        <select class="form-select" name="book_type" id="book_type" style="margin-bottom: 10px;" required>
                            <option value="History" selected="">History</option>
                            <option value="School">School</option>
                            <option value="Non-Fiction">Non-Fiction</option>
                            <option value="Fiction">Fiction</option>
                            <option value="Classic">Classic</option>
                            <option value="Fantasy">Fantasy</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Book Image</label>
                        <input class="form-control" type="file" name="book_image" id="book_image" style="margin-bottom: 10px;" accept="image/*">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Book Description</label>
                        <textarea class="form-control" name="book_desc" id="book_desc" style="margin-bottom: 10px;" required></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button class="btn btn-light" type="button" data-bs-dismiss="modal">Close</button>
                    <button class="btn btn-success link-light" name="submit_modal" type="submit">Save Book</button>
                </div>
            </form>
        </div>
    </div>
</div>
<script>
    $(document).on('click', '#edit-data', function(){
        let bkid = $(this).data("id");
        let img = $(this).data("image");
        let name = $(this).data("name");
        let ttl = $(this).data("total");

        $(".modal-body #book_id2").val(bkid);
        $(".modal-body #book_id_new").val(bkid);
        $(".modal-body #book_name").val(name);
        $(".modal-body #book_stock").val(ttl);
        $(".modal-body #img_ku").attr('src', img);
        $("#modal-utama").modal('toggle');
    });
</script>
<script>
    $(document).ready(function() {
      $('.owl-carousel').owlCarousel({
        loop: true,
        margin: 10,
        responsiveClass: true,
        responsive: {
          0: {
            items: 1,
            nav: true
          },
          600: {
            items: 3,
            nav: false
          },
          1000: {
            items: 5,
            nav: true,
            loop: false,
            margin: 20
          }
        }
      })
    })
</script>
<script>
    const search_field = document.getElementById('search-catalog-field');
    function sortCatalog(){
        const search_value = search_field.value;
        console.log(search_value);
        window.location = 'index.php?page=item&query='+search_value;
    }
</script>