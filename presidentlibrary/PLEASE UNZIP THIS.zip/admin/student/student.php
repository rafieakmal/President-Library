<?php
    require '../conn.php';
    $search = isset($_GET['query']) ? $_GET['query']: "";
    if (isset($_GET['query'])) {
        $search_query = isset($_GET['query']) ?
        ' WHERE student_name LIKE "%' . $_GET['query']
        . '%" OR student_email LIKE "%' . $_GET['query'] . '%" '
        : "";
        $show_query = 'SELECT * FROM student' . $search_query;
        $result = mysqli_query($conn, $show_query);
    } else {
        $show_query = 'SELECT * FROM student';
        $result = mysqli_query($conn, $show_query);
    }
?>

<?php
    if (isset($_POST['submit_modal'])) {
        $id = trim(htmlspecialchars($_POST['customer_id']));
        $new_id = trim(htmlspecialchars($_POST['customer_id_new']));
        $phone = trim(htmlspecialchars($_POST['customer_phone']));
        $name = trim(htmlspecialchars($_POST['customer_name']));
        $email = trim(htmlspecialchars($_POST['customer_email']));
        $password = $_POST['customer_password'];
        $password = password_hash($password, PASSWORD_DEFAULT);
        $query_string = "UPDATE `student` SET `student_id`='$new_id', `student_name`='$name',`student_email`='$email',`student_phone`='$phone',`student_password`='$password' WHERE `student_id`='$id'";
        $result = mysqli_query($conn, $query_string);
        if ($result) {
            echo "<script>
                alert('Data Updated!');
                window.location='./index.php?page=student';
            </script>";
        } else {
            echo "<script>
                alert('Failed to update data!');
                window.location='./index.php?page=student';
            </script>";
        }
    }
?>
<div class="container">
    <br><h1>Student Management</h1>
        <br>
        <form class="search-form"  method="get">
            <div class="input-group"><span class="input-group-text"><i class="fa fa-search"></i></span>
            <input class="form-control" type="text" placeholder="I am looking for.." id="search-catalog-field" value="<?= $search?>">
            <button class="btn btn-info text-light" type="button" onclick="sortCatalog()">Search</button></div>
        </form>
        <div class="table-responsive text-center table table-hover table-bordered results">
            <table class="table table-hover table-bordered">
                <thead class="bill-header cs">
                    <tr>
                        <th id="trs-hd-1" class="col-lg-1">No.</th>
                        <th id="trs-hd-2" class="col-lg-2">Student ID</th>
                        <th id="trs-hd-3" class="col-lg-3">Name</th>
                        <th id="trs-hd-4" class="col-lg-2">Email</th>
                        <th id="trs-hd-5" class="col-lg-2">Phone</th>
                        <th id="trs-hd-6" class="col-lg-2">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $i = 0;
                    while ($row = mysqli_fetch_assoc($result)) {
                        ++$i;?>
                        <tr>
                            <td><?= $i ?></td>
                            <td><?= htmlspecialchars($row["student_id"]) ?></td>
                            <td><?= htmlspecialchars($row["student_name"]) ?></td>
                            <td><?= htmlspecialchars($row["student_email"]) ?></td>
                            <td><?= htmlspecialchars($row["student_phone"]) ?></td>
                            <td><button class="btn btn-success" id="edit-data" data-bs-toggle="modal" data-bs-target="#modal-1" data-id="<?= htmlspecialchars($row["student_id"]) ?>" 
                            data-name="<?= htmlspecialchars($row["student_name"]) ?>" data-email="<?= htmlspecialchars($row["student_email"]) ?>" data-phone="<?= htmlspecialchars($row["student_phone"]) ?>" style="margin-left: 5px;width: 37px;"><i class="far fa-edit" style="font-size: 15px;"></i></button>
                            <button class="btn btn-danger" style="margin-left: 5px;width: 37px;" type="submit" onclick="confirm('Are You Sure ?')?window.location='student/delete.php?id=<?= $row['student_id'] ?>':null"><i class="fa fa-trash" style="font-size: 15px;"></i></button></td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<div class="modal fade" role="dialog" id="modal-1" tabindex="-1" aria-labelledby="ModalUtama" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header" style="background: linear-gradient(134deg, var(--bs-yellow) 0%, var(--bs-pink) 100%), var(--bs-blue);">
                <h4 class="modal-title text-light">Edit Student</h4><button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form method="post" enctype="multipart/form-data">
                <div class="modal-body">
                    <div class="form-group">
                        <label class="form-label">Current Student ID</label>
                        <input class="form-control" type="text" name="customer_id" id="customer_id" style="margin-top: 0px;margin-bottom: 10px;" required readonly>
                    </div>
                    <div class="form-group">
                        <label class="form-label">New Student ID</label>
                        <input class="form-control" type="text" name="customer_id_new" id="customer_id_new" style="margin-top: 0px;margin-bottom: 10px;" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">New Name</label>
                        <input class="form-control" type="text" name="customer_name" id="customer_name" style="margin-top: 0px;margin-bottom: 10px;" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">New Email</label>
                        <input class="form-control" type="email" name="customer_email" id="customer_email" style="margin-top: 0px;margin-bottom: 10px;" required>
                    <div class="form-group">
                        <label class="form-label">New Password</label>
                        <input class="form-control" type="password" name="customer_password" id="customer_password" style="margin-bottom: 10px;" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">New Phone</label>
                        <input class="form-control" type="tel" name="customer_phone" id="customer_phone" style="margin-top: 0px;margin-bottom: 10px;" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button class="btn btn-light" type="button" data-bs-dismiss="modal">Close</button>
                    <button class="btn btn-success link-light" name="submit_modal" type="submit">Save Student</button>
                </div>
            </form>
        </div>
    </div>
</div>
<script>
    $(document).on('click', '#edit-data', function(){
        let stid = $(this).data("id");
        let name = $(this).data("name");
        let email = $(this).data("email");
        let phone = $(this).data("phone");

        $(".modal-body #student_id").text(stid);
        $(".modal-body #customer_id").val(stid);
        $(".modal-body #student_name").text(name);
        $(".modal-body #student_email").text(email);
        $(".modal-body #student_phone").text(phone);
    });
</script>
<script>
    const search_field = document.getElementById('search-catalog-field');
    function sortCatalog(){
        const search_value = search_field.value;
        console.log(search_value);
        window.location = 'index.php?page=student&query='+search_value;
    }
</script>