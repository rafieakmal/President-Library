<?php
    require '../conn.php';
    $search = isset($_GET['query']) ? $_GET['query']: "";
    if (isset($_GET['query'])) {
        $search_query = isset($_GET['query']) ?
        ' WHERE book_name LIKE "%' . $_GET['query']
        . '%" OR book_type LIKE "%' . $_GET['query']
        . '%" OR book_desc LIKE "%' . $_GET['query'] . '%" '
        : "";
        $show_query = 'SELECT * FROM book' . $search_query;
        $result = mysqli_query($conn, $show_query);
    } else {
        $show_query = 'SELECT * FROM book';
        $result = mysqli_query($conn, $show_query);
    }
?>

<?php
    if (isset($_POST['submit_modal'])) {
        $id = trim(htmlspecialchars($_POST['book_id']));
        $name = trim(htmlspecialchars($_POST['book_name']));
        $type = trim(htmlspecialchars($_POST['book_type']));
        $stock = trim(htmlspecialchars($_POST['book_stock']));
        $desc = trim(htmlspecialchars($_POST['book_desc']));
        $pict = $_FILES['book_image']['name'];
        $ext = explode(".", $_FILES['book_image']['name']);
        $image = "img-" . round(microtime(true)) . "." . end($ext);
        $sumber = $_FILES['book_image']['tmp_name'];
        $upload = move_uploaded_file($sumber, "../assets/img/book/" . $image);
        if($upload) {
            $query_string = "INSERT INTO book VALUES ('$id', '$name', '$type', '$image', '$desc', '$stock')";
            $result = mysqli_query($conn, $query_string);
            echo "<script>
                alert('Updated!');
                window.location='./index.php';
            </script>";
        } else {
            echo "<script>
                console.log('".$_FILES['book_image']['error']."');
            </script>";
        }
    }
?>

<?php
    $show_query = 'SELECT * FROM book';
    $book_result = mysqli_query($conn, $show_query);
    $std_query = 'SELECT * FROM student';
    $std_result = mysqli_query($conn, $std_query);
    $lib_query = 'SELECT * FROM librarian';
    $lib_result = mysqli_query($conn, $lib_query);
    $payment_query = "SELECT * FROM loan WHERE status = 'Request'";
    $payment_result = mysqli_query($conn, $payment_query);
    $over_query = "SELECT * FROM loan WHERE status = 'Overdue'";
    $over_result = mysqli_query($conn, $over_query);
    $req_query = "SELECT * FROM loan WHERE status = 'Pending'";
    $req_result = mysqli_query($conn, $req_query);
    $ret_query = "SELECT * FROM loan WHERE status = 'Returning'";
    $ret_result = mysqli_query($conn, $ret_query);
    $ret2_query = "SELECT * FROM loan WHERE status = 'Returned'";
    $ret2_result = mysqli_query($conn, $ret2_query);
?>

<div class="container">
    <br><h1>Dashboard</h1>
    <div class="row">
    <div class="col-md-6 col-xl-3 mb-4">
            <div class="card shadow border-start-primary py-2">
                <div class="card-body">
                    <div class="row align-items-center no-gutters">
                        <div class="col me-2">
                            <div class="text-uppercase text-primary fw-bold text-xs mb-1"><span>LIBRARIAN</span></div>
                            <?php $i = 0;
                            while ($row = mysqli_fetch_assoc($lib_result)) {
                                ++$i;
                            } ?>
                            <div class="text-dark fw-bold h5 mb-0"><span><?= $i ?></span></div>
                            <div class="text-dark fw-bold h5 mb-0"></div>
                        </div>
                        <div class="col-auto"><i class="fas fa-user fa-2x text-gray-300"></i></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-6 col-xl-3 mb-4">
            <div class="card shadow border-start-primary py-2">
                <div class="card-body">
                    <div class="row align-items-center no-gutters">
                        <div class="col me-2">
                            <div class="text-uppercase text-primary fw-bold text-xs mb-1"><span>STUDENT</span></div>
                            <?php $i = 0;
                            while ($row = mysqli_fetch_assoc($std_result)) {
                                ++$i;
                            } ?>
                            <div class="text-dark fw-bold h5 mb-0"><span><?= $i ?></span></div>
                            <div class="text-dark fw-bold h5 mb-0"></div>
                        </div>
                        <div class="col-auto"><i class="fas fa-user fa-2x text-gray-300"></i></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-6 col-xl-3 mb-4">
            <div class="card shadow border-start-success py-2">
                <div class="card-body">
                    <div class="row align-items-center no-gutters">
                        <div class="col me-2">
                            <div class="text-uppercase text-success fw-bold text-xs mb-1"><span>books</span></div>
                            <?php $i = 0;
                            while ($row = mysqli_fetch_assoc($book_result)) {
                                ++$i;
                            } ?>
                            <div class="text-dark fw-bold h5 mb-0"><span><?= $i ?></span></div>
                        </div>
                        <div class="col-auto"><i class="fas fa-book fa-2x text-gray-300"></i></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-6 col-xl-3 mb-4">
            <div class="card shadow border-start-success py-2">
                <div class="card-body">
                    <div class="row align-items-center no-gutters">
                        <div class="col me-2">
                            <div class="text-uppercase text-success fw-bold text-xs mb-1"><span>RETURNED</span></div>
                            <?php $i = 0;
                            while ($row = mysqli_fetch_assoc($ret2_result)) {
                                ++$i;
                            } ?>
                            <div class="text-dark fw-bold h5 mb-0"><span><?= $i ?></span></div>
                        </div>
                        <div class="col-auto"><i class="fas fa-book fa-2x text-gray-300"></i></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-6 col-xl-3 mb-4">
            <div class="card shadow border-start-success py-2">
                <div class="card-body">
                    <div class="row align-items-center no-gutters">
                        <div class="col me-2">
                            <div class="text-uppercase text-danger fw-bold text-xs mb-1"><span>BORROW REQUESTS</span></div>
                            <?php $i = 0;
                            while ($row = mysqli_fetch_assoc($req_result)) {
                                ++$i;
                            } ?>
                            <div class="text-dark fw-bold h5 mb-0"><span><?= $i ?></span></div>
                        </div>
                        <div class="col-auto"><i class="fas fa-book fa-2x text-gray-300"></i></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-6 col-xl-3 mb-4">
            <div class="card shadow border-start-success py-2">
                <div class="card-body">
                    <div class="row align-items-center no-gutters">
                        <div class="col me-2">
                            <div class="text-uppercase text-danger fw-bold text-xs mb-1"><span>RETURNING REQUESTS</span></div>
                            <?php $i = 0;
                            while ($row = mysqli_fetch_assoc($ret_result)) {
                                ++$i;
                            } ?>
                            <div class="text-dark fw-bold h5 mb-0"><span><?= $i ?></span></div>
                        </div>
                        <div class="col-auto"><i class="fas fa-book fa-2x text-gray-300"></i></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-6 col-xl-3 mb-4">
            <div class="card shadow border-start-info py-2">
                <div class="card-body">
                    <div class="row align-items-center no-gutters">
                        <div class="col me-2">
                            <div class="text-uppercase text-danger fw-bold text-xs mb-1"><span>OVERDUE</span></div>
                            <?php $i = 0;
                            while ($row = mysqli_fetch_assoc($over_result)) {
                                ++$i;
                            } ?>
                            <div class="text-dark fw-bold h5 mb-0"><span><?= $i ?></span></div>
                        </div>
                        <div class="col-auto"><i class="far fa-credit-card fa-2x text-gray-300"></i></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-6 col-xl-3 mb-4">
            <div class="card shadow border-start-info py-2">
                <div class="card-body">
                    <div class="row align-items-center no-gutters">
                        <div class="col me-2">
                            <div class="text-uppercase text-danger fw-bold text-xs mb-1"><span>PAYMENT REQUESTS</span></div>
                            <?php $i = 0;
                            while ($row = mysqli_fetch_assoc($payment_result)) {
                                ++$i;
                            } ?>
                            <div class="text-dark fw-bold h5 mb-0"><span><?= $i ?></span></div>
                        </div>
                        <div class="col-auto"><i class="far fa-credit-card fa-2x text-gray-300"></i></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="container">
    <br><h1>All Books</h1>
        <br>
        <form class="search-form"  method="get">
            <div class="input-group"><span class="input-group-text"><i class="fa fa-search"></i></span>
            <input class="form-control" type="text" placeholder="I am looking for.." id="search-catalog-field" value="<?= $search?>">
            <button class="btn btn-info text-light" type="button" onclick="sortCatalog()">Search</button></div>
        </form>
        <div class="table-responsive text-center table table-hover table-bordered results">
            <table class="table table-hover table-bordered">
                <thead class="bill-header cs">
                    <tr>
                        <th id="trs-hd-1" class="col-lg-1">No.</th>
                        <th id="trs-hd-2" class="col-lg-2">Book ID</th>
                        <th id="trs-hd-3" class="col-lg-3">Name</th>
                        <th id="trs-hd-4" class="col-lg-2">Type</th>
                        <th id="trs-hd-5" class="col-lg-2">Total</th>
                        <th id="trs-hd-5" class="col-lg-2">Image</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $i = 0;
                    while ($row = mysqli_fetch_assoc($result)) {
                        ++$i;?>
                        <tr>
                            <td><?= $i ?></td>
                            <td><?= htmlspecialchars($row["book_id"]) ?></td>
                            <td><?= htmlspecialchars($row["book_name"]) ?></td>
                            <td><?= htmlspecialchars($row["book_type"]) ?></td>
                            <td><?= htmlspecialchars($row["book_total"]) ?></td>
                            <td><?= htmlspecialchars($row["book_image"]) ?></td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<div class="container">
    <button class="btn btn-success link-light" id="edit-data" type="button">Add Book</button>
</div>

<script>
    $(document).on('click', '#edit-data', function(){
        $("#modal-utama").modal('toggle');
    });
</script>

<script>
    const search_field = document.getElementById('search-catalog-field');
    function sortCatalog(){
        const search_value = search_field.value;
        console.log(search_value);
        window.location = 'index.php?query='+search_value;
    }
</script>

<div class="modal fade" role="dialog" id="modal-utama" tabindex="-1" aria-labelledby="ModalUtama" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header" style="background: linear-gradient(134deg, var(--bs-yellow) 0%, var(--bs-pink) 100%), var(--bs-blue);">
                <h4 class="modal-title text-light">Add New Book</h4><button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form method="post" enctype="multipart/form-data">
                <div class="modal-body">
                    <div class="form-group">
                        <label class="form-label">Book ID</label>
                        <input class="form-control" type="text" name="book_id" id="book_id" style="margin-top: 0px;margin-bottom: 10px;" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Book Name</label>
                        <input class="form-control" type="text" name="book_name" id="book_name" style="margin-top: 0px;margin-bottom: 10px;" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Book Stock</label>
                        <input class="form-control" type="text" name="book_stock" id="book_stock" style="margin-top: 0px;margin-bottom: 10px;" required>
                    <div class="form-group">
                        <label class="form-label">Book Type</label>
                        <select class="form-select" name="book_type" id="book_type" style="margin-bottom: 10px;" required>
                            <option value="History" selected="">History</option>
                            <option value="School">School</option>
                            <option value="Non-Fiction">Non-Fiction</option>
                            <option value="Fiction">Fiction</option>
                            <option value="Classic">Classic</option>
                            <option value="Fantasy">Fantasy</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Book Image</label>
                        <input class="form-control" type="file" name="book_image" id="book_image" style="margin-bottom: 10px;" accept="image/*" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Book Description</label>
                        <textarea class="form-control" name="book_desc" id="book_desc" style="margin-bottom: 10px;" required></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button class="btn btn-light" type="button" data-bs-dismiss="modal">Close</button>
                    <button class="btn btn-success link-light" name="submit_modal" type="submit">Add</button>
                </div>
            </form>
        </div>
    </div>
</div>
<script src="assets/bootstrap/js/bootstrap.min.js"></script>