<?php
    session_start();
    if(!isset($_SESSION['admin'])) {
        exit;
    }
    require_once 'conn.php';
    if (isset($_GET['id'])){
        $delete_query = "DELETE FROM book WHERE book_id = '".$_GET['id']."'";
        /** @var mysqli $conn */
        $result = mysqli_query($conn, $delete_query);
        if ($result) {
            echo "<script>alert('Deleted nih');window.location='../index.php?page=item'</script>";
        } else {
            echo "<script>alert('Failed to delete');window.location='../index.php?page=item'</script>";
        }
    }
?>