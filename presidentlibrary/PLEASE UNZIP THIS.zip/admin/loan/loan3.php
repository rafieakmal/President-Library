<?php
    $search = isset($_GET['query']) ? $_GET['query']: "";
    if (isset($_GET['query'])) {
        $search_query = isset($_GET['query']) ?
        ' WHERE student_id LIKE "%' . $_GET['query'] . '%" '
        : "";
        $show_query = "SELECT * FROM loan" . $search_query . "AND status = 'Returning'";
        $result = mysqli_query($conn, $show_query);
    } else {
        $show_query = "SELECT * FROM loan WHERE status = 'Returning'";
        $result = mysqli_query($conn, $show_query);
    }
?>

<?php 
    date_default_timezone_set("Asia/Jakarta");
    $datetime = date('Y-m-d H:i:s');
    $datetime_new = date('Y-m-d H:i:s', strtotime('+3 days'));
?>
<div class="container">
    <br><h1>Loan Management</h1>
        <br>
        <h4 class="text-center">Book Return Request</h4>
        <form class="search-form"  method="get">
            <div class="input-group"><span class="input-group-text"><i class="fa fa-search"></i></span>
            <input class="form-control" type="text" placeholder="I am looking for.." id="search-catalog-field" value="<?= $search?>">
            <button class="btn btn-info text-light" type="button" onclick="sortCatalog()">Search</button></div>
        </form>
        <div class="table-responsive text-center table table-hover table-bordered results">
            <table class="table table-hover table-bordered">
                <thead class="bill-header cs">
                    <tr>
                        <th id="trs-hd-1" class="col-lg-1">No.</th>
                        <th id="trs-hd-2" class="col-lg-2">Student ID</th>
                        <th id="trs-hd-2" class="col-lg-2">Loan ID</th>
                        <th id="trs-hd-3" class="col-lg-3">Book ID</th>
                        <th id="trs-hd-4" class="col-lg-2">Total Days</th>
                        <th id="trs-hd-6" class="col-lg-2">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $i = 0;
                    while ($row = mysqli_fetch_assoc($result)) {
                        $date_db = $row['total_day'];
                        $datetime_new = $row['deadline_date'];
                        ++$i;?>
                        <tr>
                            <td><?= $i ?></td>
                            <td><?= htmlspecialchars($row["student_id"]) ?></td>
                            <td><?= htmlspecialchars($row["loan_id"]) ?></td>
                            <td><?= htmlspecialchars($row["book_id"]) ?></td>
                            <td><?= htmlspecialchars($row["total_day"]) ?> days</td>
                            <td><button class="btn btn-success" id="edit-data" data-id="<?= htmlspecialchars($row["loan_id"]) ?>" 
                            data-datebefore="<?= htmlspecialchars($datetime) ?>" data-dateafter="<?= htmlspecialchars($datetime_new) ?>"
                            data-dateexpected="<?= htmlspecialchars($datetime_new_string) ?>"
                            data-image="../assets/img/user/<?= htmlspecialchars($row["student_card"]) ?>" data-day="<?= htmlspecialchars($row["total_day"]) ?>" 
                            data-stid="<?= htmlspecialchars($row["student_id"]) ?>" data-bkid="<?= htmlspecialchars($row["book_id"]) ?>" style="margin-left: 5px;"><i class="fas fa-search" style="font-size: 15px;"></i></button>
                            </td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<div class="container">
    <div class="row">
        <div class="col-md-6"><button id="back-page" class="btn btn-danger" type="button">Back</button></div>
    </div>
</div>
<div class="modal fade" role="dialog" id="modal-1" tabindex="-1" aria-labelledby="ModalUtama" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header" style="background: linear-gradient(134deg, var(--bs-yellow) 0%, var(--bs-pink) 100%), var(--bs-blue);">
                <h4 class="modal-title text-light">Confirmed Book</h4><button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="loan/overdue.php" method="post" enctype="multipart/form-data">
                <div class="modal-body">
                    <div class="container" style="width: 400px;">
                        <div class="row">
                            <div class="col-md-12"><img class="img-fluid" id="img_ku" name="img_ku" src="assets/img/OIP%20(3).jpg"></div>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Loan ID</label>
                        <input class="form-control" type="text" name="loan_id" id="loan_id" style="margin-top: 0px;margin-bottom: 10px;" required readonly>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Student ID</label>
                        <input class="form-control" type="text" name="customer_id" id="customer_id" style="margin-top: 0px;margin-bottom: 10px;" required readonly>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Book ID</label>
                        <input class="form-control" type="text" name="book_id" id="book_id" style="margin-top: 0px;margin-bottom: 10px;" required readonly>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Days</label>
                        <input class="form-control" type="text" name="total_day" id="total_day" style="margin-top: 0px;margin-bottom: 10px;" required readonly>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Deadline Date</label>
                        <input class="form-control" type="text" name="date_after" id="date_after" style="margin-top: 0px;margin-bottom: 10px;" required readonly>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Tax</label>
                        <input class="form-control" type="text" name="tax_amount" id="tax_amount" style="margin-top: 0px;margin-bottom: 10px;" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Select Status</label>
                        <select class="form-select" name="status_type" id="status_type" style="margin-bottom: 10px;" required>
                            <option value="Overdue" selected="">Overdue</option>
                            <option value="Returned">Return In Time</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button class="btn btn-light" type="button" data-bs-dismiss="modal">Close</button>
                    <button class="btn btn-success link-light" name="submit_modal" type="submit">Submit</button>
                </div>
            </form>
        </div>
    </div>
</div>
<script>
    $(document).on('click', '#back-page', function(){
        window.location = 'index.php?page=loan2';
    });
</script>
<script>
    $(document).on('click', '#edit-data', function(){
        let stid = $(this).data("stid");
        let loan_id = $(this).data("id");
        let bkid = $(this).data("bkid");
        let image = $(this).data("image");
        let day = $(this).data("day");
        let date_after = $(this).data("dateafter");

        $(".modal-body #customer_id").val(stid);
        $(".modal-body #loan_id").val(loan_id);
        $(".modal-body #book_id").val(bkid);
        $(".modal-body #total_day").val(day);
        $(".modal-body #date_after").val(date_after);
        $(".modal-body #img_ku").attr('src', image);
        $("#modal-1").modal('toggle');
    });
</script>
<script>
    const search_field = document.getElementById('search-catalog-field');
    function sortCatalog(){
        const search_value = search_field.value;
        console.log(search_value);
        window.location = 'index.php?page=loan3&query='+search_value;
    }
</script>