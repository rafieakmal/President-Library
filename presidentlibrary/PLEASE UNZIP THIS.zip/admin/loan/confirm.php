<?php
    session_start();
    require_once 'conn.php';
    if(!isset($_SESSION['admin'])) {
        exit;
    }
    if (isset($_POST['submit_modal'])) {
        $id = trim(htmlspecialchars($_POST['loan_id']));
        $date_now = trim(htmlspecialchars($_POST['date_now']));
        $date_line = trim(htmlspecialchars($_POST['date_after']));
        $status = "Confirmed";
        $show_query = "SELECT * FROM loan WHERE loan_id = '$id' AND status = 'Pending'";
        $result = mysqli_query($conn, $show_query);
        if($result) {
            $row = mysqli_fetch_assoc($result);
            $update_id = $row['book_id'];
            $show_book = "SELECT * FROM book WHERE book_id = '$update_id'";
            $result_book = mysqli_query($conn, $show_book);
            if($result_book) {
                $row_book = mysqli_fetch_assoc($result_book);
                $book_total = (int) $row_book['book_total'] - 1;
                $change_book_total = "UPDATE `book` SET `book_total`='$book_total' WHERE `book_id`='$update_id'";
                $result_new = mysqli_query($conn, $change_book_total);
                if($result_new) {
                    $checkout_query = "UPDATE `loan` SET `status`='$status', `curr_date`='$date_now', `deadline_date`='$date_line' WHERE `loan_id`='$id' AND `status` = 'Pending'";
                    $result_query = mysqli_query($conn, $checkout_query);
                    if ($result_query) {
                        echo "<script>
                            alert('Data Updated!');
                            window.location='../index.php?page=loan';
                        </script>";
                    } else {
                        echo "<script>
                            alert('Failed to update data!');
                            window.location='../index.php?page=loan';
                        </script>";
                    }
                } else {
                    $reason = mysqli_error($conn);
                    echo "<script>
                        alert('$reason');
                        window.location='../index.php?page=loan';
                    </script>";
                }
            } else {
                $reason = mysqli_error($conn);
                echo "<script>
                    alert('$reason');
                    window.location='../index.php?page=loan';
                </script>";
            }
        } else {
            $reason = mysqli_error($conn);
            echo "<script>
                alert('$reason');
                window.location='../index.php?page=loan';
            </script>";
        }
    }
?>