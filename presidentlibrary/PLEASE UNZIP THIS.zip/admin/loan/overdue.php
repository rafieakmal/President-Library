<?php
    session_start();
    if(!isset($_SESSION['admin'])) {
        exit;
    }
    require_once 'conn.php';
    if(isset($_POST['submit_modal'])) {
        $status = $_POST['status_type'];
        $id = $_POST['loan_id'];
        $bkid = $_POST['book_id'];
        $data = array(
            "loan_id" => $_POST['loan_id'],
            "student_id" => $_POST['customer_id'],
            "book_id" => $_POST['book_id'],
            "status" => $_POST['status_type'],
            "overdue_tax" => $_POST['tax_amount']
        );
        $data_str = implode("', '", $data);
        if($status == "Overdue") {
            $insert_pembelian = "INSERT INTO overdue VALUES ('$data_str')";
            $result = mysqli_query($conn, $insert_pembelian);
            if ($result) {
                $checkout_query = "UPDATE `loan` SET `status`='$status' WHERE `loan_id`='$id' AND `status` = 'Returning'";
                $result_query = mysqli_query($conn, $checkout_query);
                if ($result_query) {
                    $show_book = "SELECT * FROM book WHERE book_id = '$bkid'";
                    $result_book = mysqli_query($conn, $show_book);
                    if($result_book) {
                        $row_book = mysqli_fetch_assoc($result_book);
                        $book_total = (int) $row_book['book_total'] + 1;
                        $change_book_total = "UPDATE `book` SET `book_total`='$book_total' WHERE `book_id`='$bkid'";
                        $result_new = mysqli_query($conn, $change_book_total);
                        if($result_new) {
                            echo "<script>alert('Success add data');window.location='../index.php?page=loan3'</script>";
                        }
                    } else {
                        $reason = mysqli_error($conn);
                        echo "<script>
                            alert('$reason');
                            window.location='../index.php?page=loan3';
                        </script>";
                    }
                } else {
                    $reason = mysqli_error($conn);
                    echo "<script>
                        alert('$reason');
                        window.location='../index.php?page=loan3';
                    </script>";
                    }
            } else {
                $reason = mysqli_error($conn);
                echo "<script>
                    alert('$reason');
                    window.location='../index.php?page=loan3';
                </script>";
            }
        } else {
            $checkout_query = "UPDATE `loan` SET `status`='$status' WHERE `loan_id`='$id' AND `status` = 'Returning'";
            $result_query = mysqli_query($conn, $checkout_query);
            if ($result_query) {
                $show_book = "SELECT * FROM book WHERE book_id = '$bkid'";
                $result_book = mysqli_query($conn, $show_book);
                if($result_book) {
                    $row_book = mysqli_fetch_assoc($result_book);
                    $book_total = (int) $row_book['book_total'] + 1;
                    $change_book_total = "UPDATE `book` SET `book_total`='$book_total' WHERE `book_id`='$bkid'";
                    $result_new = mysqli_query($conn, $change_book_total);
                    if($result_new) {
                        $delete_query2 = "DELETE FROM loan WHERE loan_id = '$id'";
                        $delete_result2 = mysqli_query($conn, $delete_query2);
                        if($delete_result2) {
                            echo "<script>alert('Success add data');window.location='../index.php?page=loan3'</script>";
                        }
                    }
                } else {
                    $reason = mysqli_error($conn);
                    echo "<script>
                        alert('$reason');
                        window.location='../index.php?page=loan3';
                    </script>";
                }
            } else {
                $reason = mysqli_error($conn);
                echo "<script>
                    alert('$reason');
                    window.location='../index.php?page=loan3';
                </script>";
            }
        }
        
    }
?>