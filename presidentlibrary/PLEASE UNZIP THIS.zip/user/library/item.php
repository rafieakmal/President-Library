<?php
    require 'conn.php';
    $search = isset($_GET['query']) ? $_GET['query']: "";
    $student_id = $_SESSION['user'];
    $show_query = "SELECT l.loan_id, l.status, l.curr_date, l.deadline_date, l.student_id, l.total_day, b.book_name, b.book_total, b.book_type, b.book_image, b.book_id 
    FROM loan l 
    LEFT JOIN book b on l.book_id = b.book_id WHERE l.student_id = '$student_id' ORDER BY status ASC";
    $result = mysqli_query($conn, $show_query);
?>
<!-- Owl Stylesheets -->
<link rel="stylesheet" href="../user/item/assets/owlcarousel/assets/owl.carousel.min.css">
<link rel="stylesheet" href="../user/item/assets/owlcarousel/assets/owl.theme.default.min.css">
<link rel="stylesheet" href="../user/item/assets/css/item.css">

<script src="../user/item/assets/vendors/jquery.min.js"></script>
<script src="../user/item/assets/owlcarousel/owl.carousel.js"></script>

<br>


<div class="container">
    <div class="row">
        <div class="large-12 columns">
          <div class="owl-carousel owl-theme">
          <?php $i = 0;
            while ($row = mysqli_fetch_assoc($result)) { ?>
                <div class="item">
                    <div class="card p-3">
                        <div class="text-center">
                            <?php 
                                if($row['status'] == 'On Cart') { ?>
                                    <button class="btn btn-warning border rounded-pill" type="button" style="height: 28px;padding: 2px 12px;padding-top: 1px;">ON CART</button>
                            <?php } else if($row['status'] == 'Pending') { ?>
                                <button class="btn btn-warning border rounded-pill" type="button" style="height: 28px;padding: 2px 12px;padding-top: 1px;">PENDING</button>
                            <?php } else if($row['status'] == 'Confirmed') { ?>
                                <button class="btn btn-info border rounded-pill text-light" type="button" style="height: 28px;padding: 2px 12px;padding-top: 1px;">CONFIRMED</button>
                            <?php } else if($row['status'] == 'Returning') { ?>
                                <button class="btn btn-warning border rounded-pill" type="button" style="height: 28px;padding: 2px 12px;padding-top: 1px;">RETURNING BOOK</button>
                            <?php } else if($row['status'] == 'Overdue') { ?>
                                <button class="btn btn-danger border rounded-pill" type="button" style="height: 28px;padding: 2px 12px;padding-top: 1px;">OVERDUE</button>
                            <?php } else if($row['status'] == 'Returned') { ?>
                                <button class="btn btn-success border rounded-pill" type="button" style="height: 28px;padding: 2px 12px;padding-top: 1px;">RETURNED</button>
                            <?php } else if($row['status'] == 'Request') { ?>
                                <button class="btn btn-warning border rounded-pill" type="button" style="height: 28px;padding: 2px 12px;padding-top: 1px;">ON REQUEST</button>
                            <?php } ?>
                        </div>
                        <br>
                        <div class="text-center"> <img src="../assets/img/book/<?= htmlspecialchars($row["book_image"]) ?>" width="200"> </div>
                        <div class="product-details">
                            <div class="buttons d-flex flex-row">
                            <?php if($row['status'] == 'On Cart') { ?>
                                <button class="btn btn-info text-light" id="check-detail" type="submit" onclick="window.location='./index.php?page=cart'"><i style="font-size: 15px;"></i>Check On Cart</button></td>
                            <?php } else if($row['status'] == 'Pending') { ?>
                                <button class="btn btn-info text-light" id="check-detail" type="submit" data-id='<?= $row['loan_id'] ?>' data-status='<?= $row['status'] ?>' ><i style="font-size: 15px;"></i>Check Detail</button></td>
                            <?php } else if($row['status'] == 'Confirmed') { ?>
                                <button class="btn btn-warning text-light" type="submit" onclick="confirm('Are You Sure ?')?window.location='library/borrow.php?id=<?= $row['loan_id'] ?>':null"><i style="font-size: 15px;"></i>Request Return</button></td>
                            <?php } else if($row['status'] == 'Returning') { ?>
                                <button class="btn btn-info text-light" id="check-detail" type="submit" data-id='<?= $row['loan_id'] ?>' data-status='<?= $row['status'] ?>'><i style="font-size: 15px;"></i>Check Detail</button></td>
                            <?php } else if($row['status'] == 'Overdue') { ?>
                                <button class="btn btn-danger text-light" type="submit" onclick="confirm('Are You Sure ?')?window.location='./index.php?page=transaction&loan_id=<?= $row['loan_id'] ?>':null"><i style="font-size: 15px;"></i>Pay Tax</button></td>
                            <?php } else if($row['status'] == 'Returned') { ?>
                                <button class="btn btn-success text-light" type="submit"><i style="font-size: 15px;"></i>Successful</button></td>
                            <?php } else if($row['status'] == 'Request') { ?>
                                <button class="btn btn-info text-light" id="check-detail" type="submit" data-id='<?= $row['loan_id'] ?>' data-status='<?= $row['status'] ?>'><i style="font-size: 15px;"></i>Check Detail</button></td>
                            <?php } ?>
                            </div>
                            <div class="weight"></div>
                        </div>
                    </div>
                </div>
            <?php } ?>
        </div>
    </div>
</div>

<div class="modal fade" role="dialog" id="modal-kedua" tabindex="-1" aria-labelledby="modal-kedua" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header" style="background: linear-gradient(134deg, var(--bs-yellow) 0%, var(--bs-pink) 100%), var(--bs-blue);">
                <h4 class="modal-title text-light">Loan Detail</h4><button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="item/create.php" method="post" enctype="multipart/form-data">
                <div class="modal-body">
                    <div class="form-group">
                        <label class="form-label">Loan ID</label>
                        <input class="form-control" type="text" name="loan_id" id="loan_id" style="margin-top: 0px;margin-bottom: 10px;" readonly>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Status</label>
                        <input class="form-control" type="text" name="status_id" id="status_id" style="margin-top: 0px;margin-bottom: 10px;" readonly>
                    </div>
                </div>
                <div class="modal-footer">
                    <button class="btn btn-light" type="button" data-bs-dismiss="modal">Close</button>
                </div>
            </form>
        </div>
    </div>
</div>
<script>
    $(document).on('click', '#check-detail', function(){
        let loan_id = $(this).data("id");
        let stid = $(this).data("status");

        $(".modal-body #status_id").val(stid);
        $(".modal-body #loan_id").val(loan_id);
        $("#modal-kedua").modal('toggle');
    });
</script>
<script>
    $(document).on('click', '#borrow-data', function(){
        let bkid = $(this).data("id");
        let stid = $(this).data("stid");
        let img = $(this).data("image");
        let name = $(this).data("name");
        let loan_id = $(this).data("loanid");

        $(".modal-body #customer_id").val(stid);
        $(".modal-body #loan_id").val(loan_id);

        $(".modal-body #book_id2").val(bkid);
        $(".modal-body #book_name").val(name);
        $(".modal-body #stud_id").val(stid);
        $(".modal-body #img_ku").attr('src', img);
        $("#modal-utama").modal('toggle');
    });
</script>
<script>
    $(document).ready(function() {
      $('.owl-carousel').owlCarousel({
        loop: true,
        margin: 10,
        responsiveClass: true,
        responsive: {
          0: {
            items: 1,
            nav: true
          },
          600: {
            items: 3,
            nav: false
          },
          1000: {
            items: 5,
            nav: true,
            loop: false,
            margin: 20
          }
        }
      })
    })
</script>
<script>
    const search_field = document.getElementById('search-catalog-field');
    function sortCatalog(){
        const search_value = search_field.value;
        console.log(search_value);
        window.location = 'index.php?page=library&query='+search_value;
    }
</script>