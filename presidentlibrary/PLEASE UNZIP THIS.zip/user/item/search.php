<?php
    require 'conn.php';
    $search = isset($_GET['query']) ? $_GET['query']: "";
    if (isset($_GET['query'])) {
        $search_query = isset($_GET['query']) ?
        ' WHERE book_name LIKE "%' . $_GET['query']
        . '%" OR book_type LIKE "%' . $_GET['query']
        . '%" OR book_desc LIKE "%' . $_GET['query'] . '%" '
        : "";
        $show_query = 'SELECT * FROM book' . $search_query;
        $result = mysqli_query($conn, $show_query);
    } else {
        $show_query = 'SELECT * FROM book';
        $result = mysqli_query($conn, $show_query);
    }
?>
<!-- Owl Stylesheets -->
<link rel="stylesheet" href="assets/owlcarousel/assets/owl.carousel.min.css">
<link rel="stylesheet" href="assets/owlcarousel/assets/owl.theme.default.min.css">
<link rel="stylesheet" href="assets/css/item.css">
<script src="assets/vendors/jquery.min.js"></script>
<script src="assets/owlcarousel/owl.carousel.js"></script>
<script src="../../assets/bootstrap/js/bootstrap.min.js"></script>
<div class="large-12 columns">
    <div class="owl-carousel owl-theme">
      <?php $i = 0;
        while ($row = mysqli_fetch_assoc($result)) { ?>
            <div class="item">
                <div class="card p-3">
                    <div class="text-center"> <img src="../../assets/img/book/<?= htmlspecialchars($row["book_image"]) ?>" width="200"> </div>
                    <div class="product-details">
                        <div class="buttons d-flex flex-row">
                        <?php if($row['book_total'] < 1) {?>
                            <button class="btn btn-danger text-light cart-button btn-block" href="#" type="button"><span class="dot">1</span>Not In Library</button>
                        <?php } else { ?>
                            <button class="btn btn-info text-light cart-button btn-block" id="borrow-data" data-id="<?= htmlspecialchars($row["book_id"]) ?>"
                            data-stid="<?= $_SESSION["user"] ?>" data-type="<?= htmlspecialchars($row["book_type"]) ?>"
                            data-name="<?= htmlspecialchars($row["book_name"]) ?>" data-stock="<?= htmlspecialchars($row["book_total"]) ?>" 
                            data-image="../../assets/img/book/<?= htmlspecialchars($row["book_image"]) ?>" type="button"><span class="dot">1</span>Borrow</button>
                        <?php }?>
                        </div>
                        <div class="weight"><p>Available: <?= htmlspecialchars($row["book_total"]) ?></p></div>
                    </div>
                </div>
            </div>
        <?php } ?>
    </div>
</div>


<script>
    $(document).ready(function() {
      $('.owl-carousel').owlCarousel({
        loop: true,
        margin: 10,
        responsiveClass: true,
        responsive: {
          0: {
            items: 1,
            nav: true
          },
          600: {
            items: 3,
            nav: false
          },
          1000: {
            items: 5,
            nav: true,
            loop: false,
            margin: 20
          }
        }
      })
    })
</script>