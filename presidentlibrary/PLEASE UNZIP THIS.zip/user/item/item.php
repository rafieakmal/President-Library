<?php
    require 'conn.php';
    $search = isset($_GET['query']) ? $_GET['query']: "";
    if (isset($_GET['query'])) {
        $search_query = isset($_GET['query']) ?
        ' WHERE book_name LIKE "%' . $_GET['query']
        . '%" OR book_type LIKE "%' . $_GET['query']
        . '%" OR book_desc LIKE "%' . $_GET['query'] . '%" '
        : "";
        $show_query = 'SELECT * FROM book' . $search_query;
        $result = mysqli_query($conn, $show_query);
    } else {
        $show_query = 'SELECT * FROM book';
        $result = mysqli_query($conn, $show_query);
    }
?>
<!-- Owl Stylesheets -->
<link rel="stylesheet" href="../user/item/assets/owlcarousel/assets/owl.carousel.min.css">
<link rel="stylesheet" href="../user/item/assets/owlcarousel/assets/owl.theme.default.min.css">
<link rel="stylesheet" href="../user/item/assets/css/item.css">

<script src="../user/item/assets/vendors/jquery.min.js"></script>
<script src="../user/item/assets/owlcarousel/owl.carousel.js"></script>

<div class="carousel slide" data-bs-ride="carousel" id="carousel-1" style="height: 600px;">
    <div class="carousel-inner h-100">
        <div class="carousel-item active h-100"><img class="w-100 d-block position-absolute h-100 fit-cover" src="./assets/img/homepage.jpg" alt="Slide Image" style="z-index: -1;">
            <div class="container d-flex flex-column justify-content-center h-100">
                <div class="row">
                    <div class="col-md-6 col-xl-4 offset-md-2">
                        <div style="max-width: 350px;">
                            <h2 class="text-uppercase fw-bold text-light">Ready to read another book?</h2>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<br>

<div class="container">
    <h1>Collections</h1>
</div>

<div class="container">
<form class="search-form"  method="get">
            <div class="input-group"><span class="input-group-text"><i class="fa fa-search"></i></span>
            <input class="form-control" type="text" placeholder="I am looking for.." id="search-catalog-field" value="<?= $search?>">
            <button class="btn btn-info text-light" type="button" onclick="sortCatalog()">Search</button></div>
        </form><br>
    <div class="row">
        <div class="large-12 columns">
          <div class="owl-carousel owl-theme" id="myproduct">
            <?php $i = 0;
            while ($row = mysqli_fetch_assoc($result)) { ?>
                <div class="item">
                    <div class="card p-3">
                        <div class="text-center"> <img src="../assets/img/book/<?= htmlspecialchars($row["book_image"]) ?>" width="200"> </div>
                        <div class="product-details">
                            <div class="buttons d-flex flex-row">
                            <?php if($row['book_total'] < 1) {?>
                                <button class="btn btn-danger text-light cart-button btn-block" href="#" type="button"><span class="dot">1</span>Not In Library</button>
                            <?php } else { ?>
                                <button class="btn btn-info text-light cart-button btn-block" id="borrow-data" data-id="<?= htmlspecialchars($row["book_id"]) ?>"
                                data-stid="<?= $_SESSION["user"] ?>" data-type="<?= htmlspecialchars($row["book_type"]) ?>"
                                data-name="<?= htmlspecialchars($row["book_name"]) ?>" data-stock="<?= htmlspecialchars($row["book_total"]) ?>" 
                                data-image="../assets/img/book/<?= htmlspecialchars($row["book_image"]) ?>" type="button"><span class="dot">1</span>Borrow</button>
                            <?php }?>
                            </div>
                            <div class="weight"><p>Available: <?= htmlspecialchars($row["book_total"]) ?></p></div>
                        </div>
                    </div>
                </div>
            <?php } ?>
          </div>
        </div>
    </div>
</div>
<div class="modal fade" role="dialog" id="modal-utama" tabindex="-1" aria-labelledby="ModalUtama" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header" style="background: linear-gradient(134deg, var(--bs-yellow) 0%, var(--bs-pink) 100%), var(--bs-blue);">
                <h4 class="modal-title text-light">Borrow Book</h4><button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="item/create.php" method="post" enctype="multipart/form-data">
                <div class="modal-body">
                    <div class="container" style="width: 227px;">
                        <div class="row">
                            <div class="col-md-12"><img class="img-fluid" id="img_ku" name="img_ku" src="assets/img/OIP%20(3).jpg"></div>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Student ID</label>
                        <input class="form-control" type="text" name="stud_id" id="stud_id" style="margin-top: 0px;margin-bottom: 10px;" readonly>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Book ID</label>
                        <input class="form-control" type="text" name="book_id2" id="book_id2" style="margin-top: 0px;margin-bottom: 10px;" readonly>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Book Name</label>
                        <input class="form-control" type="text" name="book_name" id="book_name" style="margin-top: 0px;margin-bottom: 10px;" readonly>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Book Stock</label>
                        <input class="form-control" type="text" name="book_stock" id="book_stock" style="margin-top: 0px;margin-bottom: 10px;" readonly>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Book Type</label>
                        <input class="form-control" type="text" name="book_type" id="book_type" style="margin-top: 0px;margin-bottom: 10px;" readonly>
                    </div>
                    <br>
                    <div class="form-group">
                        <label class="form-label text-danger">* Please provide your identity card here</label>
                        <input class="form-control" type="file" name="id_image" id="id_image" style="margin-bottom: 10px;" accept="image/*" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label text-danger">* How much days you want to borrow this book?</label>
                        <select class="form-select" name="my_day" id="my_day" style="margin-bottom: 10px;" required>
                            <option value="3" selected="">3 days</option>
                            <option value="4">4 days</option>
                            <option value="5">5 days</option>
                            <option value="6">6 days</option>
                            <option value="7">1 week</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button class="btn btn-light" type="button" data-bs-dismiss="modal">Close</button>
                    <button class="btn btn-primary link-light" name="submit_modal" type="submit">Borrow Book</button>
                </div>
            </form>
        </div>
    </div>
</div>
<script>
    $(document).on('click', '#borrow-data', function(){
        let bkid = $(this).data("id");
        let stid = $(this).data("stid");
        let img = $(this).data("image");
        let name = $(this).data("name");
        let stock = $(this).data("stock");
        let type = $(this).data("type");

        $(".modal-body #book_id2").val(bkid);
        $(".modal-body #book_name").val(name);
        $(".modal-body #book_stock").val(stock);
        $(".modal-body #book_type").val(type);
        $(".modal-body #stud_id").val(stid);
        $(".modal-body #img_ku").attr('src', img);
        $("#modal-utama").modal('toggle');
    });
</script>
<script>
    $(document).ready(function() {
      $('.owl-carousel').owlCarousel({
        loop: true,
        margin: 10,
        responsiveClass: true,
        responsive: {
          0: {
            items: 1,
            nav: true
          },
          600: {
            items: 3,
            nav: false
          },
          1000: {
            items: 5,
            nav: true,
            loop: false,
            margin: 20
          }
        }
      })
    })
</script>
<script>
    const search_field = document.getElementById('search-catalog-field');
    function sortCatalog(){
        const search_value = search_field.value;
        console.log(search_value);
        window.location = 'index.php?page=item&query='+search_value;
    }
</script>