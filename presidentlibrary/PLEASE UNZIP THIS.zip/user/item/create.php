<?php
    session_start();
    require '../../conn.php';
    require '../../id_generator.php';
    if(!isset($_SESSION['user'])) {
        exit;
    }
    if(isset($_POST['submit_modal'])) {
        date_default_timezone_set("Asia/Jakarta");
        $datetime = date('Y-m-d H:i:s');
        echo $datetime;
        $book_id = htmlspecialchars($_POST['book_id2']);
        $loan_id = "";
        $total = trim(htmlspecialchars($_POST['my_day']));
        $pict = $_FILES['id_image']['name'];
        $ext = explode(".", $_FILES['id_image']['name']);
        $image = "img-" . round(microtime(true)) . "." . end($ext);
        $sumber = $_FILES['id_image']['tmp_name'];
        $upload = move_uploaded_file($sumber, "../../assets/img/user/" . $image);
        $loan_id =  GetLoanID($conn);
        if($upload) {
            $customer_id = $_SESSION['user'];
            $status = "On Cart";
            $insert_pembelian = "INSERT INTO loan VALUES ('$loan_id', '$customer_id', '$book_id', '$status', '$image', '$total', '$datetime', '$datetime')";
            $result = mysqli_query($conn, $insert_pembelian);
            if ($result) {
                echo "<script>alert('Success add book');window.location='../index.php?page=item'</script>";
            } else {
                $reason = mysqli_error($conn);
                echo "<script>
                    alert('$reason');
                    window.location='../index.php?page=item';
                </script>";
            }
        } else {
            echo "<script>
                console.log('".$_FILES['book_image']['error']."');
            </script>";
        }
    } else {
        echo "<script>alert('ID Not Found');window.location='item.php'</script>";
    }
?>