
<?php
    require '../../conn.php';    
    if(isset($_POST['submit_modal'])) {
        $total = trim(htmlspecialchars($_POST['my_day']));
        $customer_id =  trim(htmlspecialchars($_POST['stud_id']));
        $loan_id = trim(htmlspecialchars($_POST['loan_id2']));
        $query_string = "UPDATE `loan` SET `total_day`='$total' WHERE `loan_id`='$loan_id'";
        $result = mysqli_query($conn, $query_string);
        if ($result) {
            echo "<script>alert('Success edit days');window.location='../index.php?page=cart'</script>";
        } else {
            $reason = mysqli_error($conn);
            echo "<script>
                alert('$reason');
                window.location='../index.php?page=cart';
            </script>";
        }

    } else {
        echo "<script>alert('ID Not Found');window.location='item.php'</script>";
    }
?>