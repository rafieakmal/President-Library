<?php
    $customer_id = $_SESSION['user'];
    $show_detail = "SELECT l.loan_id, l.total_day, b.book_name, b.book_total, b.book_type, b.book_image, b.book_id FROM loan l 
    LEFT JOIN book b on l.book_id = b.book_id WHERE l.status = 'On Cart' AND l.student_id = '$customer_id'";
    $result_detail = mysqli_query($conn, $show_detail);
    if (!$result_detail) {
      return;
    }
?>

<?php
    $customer_id = $_SESSION['user'];
    $show_detail = "SELECT l.loan_id, l.total_day, b.book_name, b.book_total, b.book_type, b.book_image, b.book_id FROM loan l 
    LEFT JOIN book b on l.book_id = b.book_id WHERE l.status = 'On Cart' AND l.student_id = '$customer_id'";
    $result = mysqli_query($conn, $show_detail);
    if (!$result) {
      return;
    }
?>

<?php
    $customer_id = $_SESSION['user'];
    $show_detail = "SELECT l.loan_id, l.student_id, l.total_day, b.book_name, b.book_total, b.book_type, b.book_image, b.book_id FROM loan l 
    LEFT JOIN book b on l.book_id = b.book_id WHERE l.status = 'On Cart' AND l.student_id = '$customer_id' limit 1;";
    $result_new = mysqli_query($conn, $show_detail);
    if (!$result_new) {
      return;
    }
?>

<div class="container"><div class="shopping-cart">
<div class="px-4 px-lg-0">

  <div class="pb-5">
    <div class="container">
      <div class="row">
        <div class="col-lg-12 p-5 bg-white rounded shadow-sm mb-5">

          <!-- Shopping cart table -->
          <div class="table-responsive">
            <table class="table">
              <thead>
                <tr>
                  <th scope="col" class="border-0 bg-light">
                    <div class="p-2">Book</div>
                  </th>
                  <th scope="col" class="border-0 bg-light">
                    <div class="py-2">Day(s)</div>
                  </th>
                  <th scope="col" class="border-0 bg-light">
                    <div class="py-2">Action</div>
                  </th>
                </tr>
              </thead>
              <tbody>
              <?php $i = 0;
                while ($row = mysqli_fetch_assoc($result_detail)) {
                ?>
                  <tr>
                    <td scope="row" class="border-0">
                      <div class="p-2">
                        <img src="../assets/img/book/<?= htmlspecialchars($row["book_image"]) ?>" alt="" width="70" class="img-fluid rounded shadow-sm">
                        <div class="ml-3 d-inline-block align-middle">
                          <h5 class="mb-0"><?= htmlspecialchars($row["book_name"]) ?></h5>
                          <span class="text-muted font-weight-normal font-italic d-block">Category: <?= htmlspecialchars($row["book_type"]) ?></span>
                        </div>
                      </div>
                    </td>
                    <td class="border-0 align-middle"><strong><?= htmlspecialchars($row["total_day"]) ?> Days</strong></a></td>
                    <td class="action-cell border-0 align-middle">
                      <button class="btn btn-warning" id="edit-data" data-id="<?= htmlspecialchars($row["loan_id"]) ?>" 
                              data-idku="<?= $_SESSION['user']; ?>" 
                                data-image="../assets/img/book/<?= htmlspecialchars($row["book_image"]) ?>" type="button">
                          <i class="fas fa-pen"></i></button>
                      <button class="btn btn-danger" onclick="confirm('Are You Sure ?')?window.location='product/delete.php?id=<?= $row['loan_id'] ?>':null">
                          <i class="fas fa-trash"></i></button>
                    </td>
                <?php } ?>
              </tbody>
            </table>
          </div>
          <!-- End -->
        </div>
      </div>

      <div class="row py-5 p-4 bg-white rounded shadow-sm">
        <div class="col-lg-6">
          <div class="bg-light rounded-pill px-4 py-3 text-uppercase font-weight-bold">Order summary</div>
          <div class="p-4">
            <ul class="list-unstyled mb-4">
             <?php $i = 0;
                  while ($row_dua = mysqli_fetch_assoc($result)) {
                  ?>
                    <li class="d-flex justify-content-between py-3 border-bottom">
                      <strong class="text-muted"><?= htmlspecialchars($row_dua["book_name"]) ?></strong>
                      <strong><?= htmlspecialchars($row_dua["total_day"]) ?> Days</strong>
                    </li>
              <?php } ?>
            </ul>
            <?php
              $line = mysqli_fetch_assoc($result_new); 
            ?>
            <button class="btn btn-info rounded-pill text-light py-2 btn-block" onclick="confirm('Are You Sure ?')?window.location='product/checkout.php?id=<?= htmlspecialchars($line["student_id"]) ?>':null">
            Procceed to checkout</button>
          </div>
        </div>
      </div>

    </div>
  </div>
</div>
</div></div>

<div class="modal fade modal-utama" role="dialog" id="modal-utama" tabindex="-1" aria-labelledby="modal-utama" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header" style="background: linear-gradient(134deg, var(--bs-yellow) 0%, var(--bs-pink) 100%), var(--bs-blue);">
                <h4 class="modal-title text-light">Edit Days</h4><button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="product/edit.php" method="post" enctype="multipart/form-data">
                <div class="modal-body">
                    <div class="container" style="width: 227px;">
                        <div class="row">
                            <div class="col-md-12"><img class="img-fluid" id="img_ku" name="img_ku" src="assets/img/OIP%20(3).jpg"></div>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Loan ID</label>
                        <input class="form-control" type="text" name="loan_id2" id="loan_id2" style="margin-top: 0px;margin-bottom: 10px;" readonly>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Student ID</label>
                        <input class="form-control" type="text" name="stud_id" id="stud_id" style="margin-top: 0px;margin-bottom: 10px;" readonly>
                    </div>
                    <br>
                    <div class="form-group">
                        <label class="form-label text-danger">* How much days you want to borrow this book?</label>
                        <select class="form-select" name="my_day" id="my_day" style="margin-bottom: 10px;" required>
                            <option value="3" selected="">3 days</option>
                            <option value="4">4 days</option>
                            <option value="5">5 days</option>
                            <option value="6">6 days</option>
                            <option value="7">1 week</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button class="btn btn-light" type="button" data-bs-dismiss="modal">Close</button>
                    <button class="btn btn-primary link-light" name="submit_modal" type="submit">Save</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
    $(document).on('click', '#edit-data', function(){
        let bkid = $(this).data("id");
        let stid = $(this).data("idku");
        let img = $(this).data("image");

        $(".modal-body #loan_id2").val(bkid);
        $(".modal-body #stud_id").val(stid);
        $(".modal-body #img_ku").attr('src', img);
        $("#modal-utama").modal('toggle');
    });
</script>