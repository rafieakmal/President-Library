<?php
  $order = $_GET['loan_id'];
  if($order) {
    $result_sql = "SELECT l.loan_id, l.total_day, o.student_id, o.status, o.overdue_tax, o.book_id FROM loan l 
    LEFT JOIN overdue o on l.loan_id = o.loan_id WHERE l.status = 'Overdue' AND l.loan_id = '$order'";
    $hasil = mysqli_query($conn,$result_sql) or die(mysqli_error($conn));;
    $id = '';
    $total_day = '';
    $student_id = '';
    $status = '';
    $overdue_tax = '';
    $book_id = '';
    while($row = mysqli_fetch_assoc($hasil)){
      $id = $row['loan_id'];
      $total_day = $row['total_day'];
      $student_id = $row['student_id'];
      $status = $row['status'];
      $overdue_tax = $row['overdue_tax'];
      $book_id = $row['book_id'];
    }
  } else {
    return;
  }
?>

<?php
    $result_sql = "SELECT l.loan_id, l.total_day, o.student_id, o.status, o.overdue_tax, o.book_id FROM loan l 
    LEFT JOIN overdue o on l.loan_id = o.loan_id WHERE l.status = 'Overdue' AND l.loan_id = '$order'";
    $hasil = mysqli_query($conn,$result_sql) or die(mysqli_error($conn));;
?>

<?php
    $result_s = "SELECT l.loan_id, l.total_day, o.student_id, o.status, o.overdue_tax, o.book_id FROM loan l 
    LEFT JOIN overdue o on l.loan_id = o.loan_id WHERE l.status = 'Overdue' AND l.loan_id = '$order'";
    $result_new = mysqli_query($conn,$result_s) or die(mysqli_error($conn));;
    if (!$result_new) {
      return;
    }
?>

<?php
    $customer_id = $_SESSION['user'];
    $show_detail = "SELECT l.loan_id, l.total_day, o.student_id, o.status, o.overdue_tax, o.book_id FROM loan l 
    LEFT JOIN overdue o on l.loan_id = o.loan_id WHERE l.status = 'Overdue' AND l.loan_id = '$customer_id' limit 1";
    $result_lagi = mysqli_query($conn, $show_detail);
    if (!$result_lagi) {
      return;
    }
?>

<div class="container"><div class="shopping-cart">
  <div class="px-4 px-lg-0">
    <div class="pb-5">
      <div class="container">
        <div class="row">
          <div class="col-lg-12 p-5 bg-white rounded shadow-sm mb-5">
            <!-- Shopping cart table -->
            <div class="table-responsive">
              <table class="table">
                <thead>
                  <tr>
                    <th scope="col" class="border-0 bg-light">
                      <div class="p-2">Detail</div>
                    </th>
                    <th scope="col" class="border-0 bg-light">
                      <div class="py-2">Deadline Tax</div>
                    </th>
                  </tr>
                </thead>
                <tbody>
                <?php $i = 0;
                  while ($row = mysqli_fetch_assoc($hasil)) {
                    $id = htmlspecialchars($row["loan_id"]);
                  ?>
                    <tr>
                      <td class="border-0 align-middle"><strong><?= htmlspecialchars($row["loan_id"]) ?></strong></a></td>
                      <td class="border-0 align-end"><strong><?= htmlspecialchars($row["overdue_tax"]) ?></strong></a></td>
                    </tr>
                  <?php } ?>
                </tbody>
              </table>
            </div>
            <button class="btn btn-info rounded-pill text-light py-2 btn-block" onclick="confirm('Are You Sure ?')?window.location='./index.php?page=pending&loan_id=<?= $id ?>':null">
              Procceed to checkout</button>
            <!-- End -->
          </div>
        </div>
      </div>
    </div>
  </div>
</div>