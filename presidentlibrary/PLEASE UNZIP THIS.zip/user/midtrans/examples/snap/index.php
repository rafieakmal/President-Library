<?php
  namespace Midtrans;
  require_once dirname(__FILE__) . '/../../Midtrans.php';
  Config::$serverKey = 'SB-Mid-server-RPM7G9VrHx36fgOHGnvVoxBu';
  Config::$clientKey = 'SB-Mid-client-o3x7QROTlZdcdD1J';

  // Required
  $transaction_details = array(
      'order_id' => rand(),
      'gross_amount' => 14000, // no decimal allowed for creditcard
  );

  // Optional
  $item1_details = array(
      'id' => 'D1',
      'price' => 14000,
      'quantity' => 1,
      'name' => "Bayar Deadline"
  );

  // Optional
  $item_details = array ($item1_details);

  // Optional
  $billing_address = array(
      'first_name'    => "Rafie",
      'last_name'     => "Akmal Haryanto",
      'address'       => "Bintara",
      'city'          => "Bekasi",
      'postal_code'   => "17134",
      'phone'         => "082111360417",
      'country_code'  => 'IDN'
  );

  // Optional
  $shipping_address = array(
      'first_name'    => "Rafie",
      'last_name'     => "Akmal Haryanto",
      'address'       => "Bintara",
      'city'          => "Bekasi",
      'postal_code'   => "17134",
      'phone'         => "082111360417",
      'country_code'  => 'IDN'
  );

  // Optional
  $customer_details = array(
      'first_name'    => "Rafie",
      'last_name'     => "Akmal Haryanto",
      'email'         => "rafie@gmail.com",
      'phone'         => "082111360417",
      'billing_address'  => $billing_address,
      'shipping_address' => $shipping_address
  );

  // Fill transaction details
  $transaction = array(
      'transaction_details' => $transaction_details,
      'customer_details' => $customer_details,
      'item_details' => $item_details,
  );

  $snap_token = '';
  try {
      $snap_token = Snap::getSnapToken($transaction);
  }
  catch (\Exception $e) {
      echo $e->getMessage();
  }
?>

<?php
    $customer_id = $_SESSION['user'];
    $show_detail = "SELECT l.loan_id, l.total_day, b.book_name, b.book_total, b.book_type, b.book_image, b.book_id FROM loan l 
    LEFT JOIN book b on l.book_id = b.book_id WHERE l.status = 'On Cart' AND l.student_id = '$customer_id'";
    $result_detail = mysqli_query($conn, $show_detail);
    if (!$result_detail) {
      return;
    }
?>

<?php
    $customer_id = $_SESSION['user'];
    $show_detail = "SELECT l.loan_id, l.total_day, b.book_name, b.book_total, b.book_type, b.book_image, b.book_id FROM loan l 
    LEFT JOIN book b on l.book_id = b.book_id WHERE l.status = 'On Cart' AND l.student_id = '$customer_id'";
    $result = mysqli_query($conn, $show_detail);
    if (!$result) {
      return;
    }
?>

<?php
    $customer_id = $_SESSION['user'];
    $show_detail = "SELECT l.loan_id, l.student_id, l.total_day, b.book_name, b.book_total, b.book_type, b.book_image, b.book_id FROM loan l 
    LEFT JOIN book b on l.book_id = b.book_id WHERE l.status = 'On Cart' AND l.student_id = '$customer_id' limit 1;";
    $result_new = mysqli_query($conn, $show_detail);
    if (!$result_new) {
      return;
    }
?>

<div class="container"><div class="shopping-cart">
<div class="px-4 px-lg-0">

  <div class="pb-5">
    <div class="container">
      <div class="row">
        <div class="col-lg-12 p-5 bg-white rounded shadow-sm mb-5">

          <!-- Shopping cart table -->
          <div class="table-responsive">
            <table class="table">
              <thead>
                <tr>
                  <th scope="col" class="border-0 bg-light">
                    <div class="p-2">Book</div>
                  </th>
                  <th scope="col" class="border-0 bg-light">
                    <div class="py-2">Day(s)</div>
                  </th>
                  <th scope="col" class="border-0 bg-light">
                    <div class="py-2">Action</div>
                  </th>
                </tr>
              </thead>
              <tbody>
              <?php $i = 0;
                while ($row = mysqli_fetch_assoc($result_detail)) {
                ?>
                  <tr>
                    <td scope="row" class="border-0">
                      <div class="p-2">
                        <img src="../assets/img/book/<?= htmlspecialchars($row["book_image"]) ?>" alt="" width="70" class="img-fluid rounded shadow-sm">
                        <div class="ml-3 d-inline-block align-middle">
                          <h5 class="mb-0"><?= htmlspecialchars($row["book_name"]) ?></h5>
                          <span class="text-muted font-weight-normal font-italic d-block">Category: <?= htmlspecialchars($row["book_type"]) ?></span>
                        </div>
                      </div>
                    </td>
                    <td class="border-0 align-middle"><strong><?= htmlspecialchars($row["total_day"]) ?> Days</strong></a></td>
                    <td class="action-cell border-0 align-middle">
                      <button class="btn btn-warning" id="edit-data" data-id="<?= htmlspecialchars($row["loan_id"]) ?>" 
                              data-idku="<?= $_SESSION['user']; ?>" 
                                data-image="../assets/img/book/<?= htmlspecialchars($row["book_image"]) ?>" type="button">
                          <i class="fas fa-pen"></i></button>
                      <button class="btn btn-danger" onclick="confirm('Are You Sure ?')?window.location='product/delete.php?id=<?= $row['loan_id'] ?>':null">
                          <i class="fas fa-trash"></i></button>
                    </td>
                <?php } ?>
              </tbody>
            </table>
          </div>
          <!-- End -->
        </div>
      </div>

      <div class="row py-5 p-4 bg-white rounded shadow-sm">
        <div class="col-lg-6">
          <div class="bg-light rounded-pill px-4 py-3 text-uppercase font-weight-bold">Coupon code</div>
          <div class="p-4">
            <p class="font-italic mb-4">If you have a coupon code, please enter it below</p>
            <form action="test.php" method="post">
              <div class="input-group mb-4 border rounded-pill p-2">
                <input type="text" placeholder="Apply coupon" aria-describedby="button-addon3" class="form-control border-0">
                <div class="input-group-append border-0">
                  <button id="button-addon3" type="submit" class="btn btn-info text-light px-4 rounded-pill"><i class="fa fa-gift mr-2"></i> Apply coupon</button>
                </div>
              </div>      
            </form>
          </div>
        </div>
        <div class="col-lg-6">
          <div class="bg-light rounded-pill px-4 py-3 text-uppercase font-weight-bold">Order summary</div>
          <div class="p-4">
            <ul class="list-unstyled mb-4">
             <?php $i = 0;
                  while ($row_dua = mysqli_fetch_assoc($result)) {
                  ?>
                    <li class="d-flex justify-content-between py-3 border-bottom">
                      <strong class="text-muted"><?= htmlspecialchars($row_dua["book_name"]) ?></strong>
                      <strong><?= htmlspecialchars($row_dua["total_day"]) ?> Days</strong>
                    </li>
              <?php } ?>
            </ul>
            <?php
              $line = mysqli_fetch_assoc($result_new); 
            ?>
            <button class="btn btn-info rounded-pill text-light py-2 btn-block" id="pay-button">
            Procceed to checkout</button>
            <pre><div id="result-json"><br></div></pre> 
          </div>
        </div>
      </div>

    </div>
  </div>
</div>
</div></div>

<script src="https://app.sandbox.midtrans.com/snap/snap.js" data-client-key="<?php echo Config::$clientKey;?>"></script>
  <script type="text/javascript">
    document.getElementById('pay-button').onclick = function(){
        // SnapToken acquired from previous step
        snap.pay('<?php echo $snap_token?>', {
            // Optional
            onSuccess: function(result){
                document.getElementById('result-json').innerHTML += JSON.stringify(result, null, 2);
            },
            // Optional
            onPending: function(result){
                document.getElementById('result-json').innerHTML += JSON.stringify(result, null, 2);
            },
            // Optional
            onError: function(result){
                document.getElementById('result-json').innerHTML += JSON.stringify(result, null, 2);
            }
        });
    };
  </script>